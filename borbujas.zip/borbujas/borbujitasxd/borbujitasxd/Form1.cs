﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Schema;

namespace borbujitasxd
{
    public partial class Form1 : Form
    {
        List<Bubble> BubbleList = new List<Bubble>(); //anytime it creates a bubble from the MakeBubbles funtion will be added to this list, ya que es easier to track objects inside a program this way

        string[] backgrounds = {"01.jpg", "02.jpg", "03.jpg", "04.jpg", "05.jpg" };

        int backgroundNumber = 1;
        Random random= new Random();
        Image background;


        public Form1()
        {
            InitializeComponent();

            SetStyle(ControlStyles.AllPaintingInWmPaint | ControlStyles.OptimizedDoubleBuffer | ControlStyles.UserPaint, true);
            background = Image.FromFile("Images/" + backgrounds[backgroundNumber]);
            //this.BackgroundImage = background;
            //this.BackgroundImageLayout = ImageLayout.Stretch;
            MakeBubbles();

        }

        private void ParticlesTimerEvent(object sender, EventArgs e)
        {
            //is where all the movements and everything else is going to happen
            foreach (Bubble tempBubble in BubbleList)
            {
                tempBubble.MoveBubble();
                tempBubble.posY -= tempBubble.speedY;
                tempBubble.posX += tempBubble.speedX;

                if(tempBubble.posY < tempBubble.topLimit)
                {
                    tempBubble.posY = 700;
                    tempBubble.posX = random.Next(0,800);
                }

            }
            this.Invalidate(); //removes everything from the display

        }

        private void Form1_KeyUp(object sender, KeyEventArgs e)
        {
            //event which is resposible for changing the background of the image
            if(e.KeyCode == Keys.Z)
            {
                backgroundNumber += 1;
                
                if(backgroundNumber > backgrounds.Length -1)
                {
                    backgroundNumber = 0;
                }
                background = Image.FromFile("Images/" + backgrounds[backgroundNumber]);
                //this.BackgroundImage = background;
            }
        }

        private void FormPaintEvent(object sender, PaintEventArgs e)
        {
            Graphics Canvas = e.Graphics;

            Canvas.DrawImage(background, 0, 0, 800, 500);

            foreach (Bubble tempBubble in BubbleList)
            {
                Canvas.DrawImage(tempBubble.bubble, tempBubble.posX, tempBubble.posY, tempBubble.width, tempBubble.height);
            }



        }

        private void MakeBubbles()
        {
            //this function will make the bubble image and get it drawn onto the screen with the paint event
            for (int i = 0; i < 300; i++)// we will be having 300 different images that are moving around the screen
            {
                //we are creating 300 different objects
                ///instancia de la bubble class
                Bubble newBubble = new Bubble();
                BubbleList.Add(newBubble);
            }
        }
    }
}
