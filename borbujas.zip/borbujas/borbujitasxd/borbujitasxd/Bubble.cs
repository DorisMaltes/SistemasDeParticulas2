﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace borbujitasxd
{
    //each buble that is spawned onto the screen will have this class attached with them
   
    internal class Bubble
    {
        //constructor, this is what runs first
        public  int height;
        public  int width;
        //these variables are going to be used to determine where the bubble is on the screen, so wich way do we need to move it
        public int posX;
        public int posY;
        //sizes of the bubble
        public int[] sizes = { 10,20,30,40,60};

        public int speedX = 1;
        public int speedY;

        public int topLimit;
        private int moveLimit;

        public Image bubble;
        Random random = new Random();


        public Bubble()
        {
            //here in the constrcutor there will be few things that we want the bubbles to do  or have when they are loeaded
            moveLimit= random.Next(50,200);

            int i = random.Next(0,sizes.Length);

            bubble = Image.FromFile("Images/bubble.png");

            height = sizes[i];
            width = sizes[i];


            topLimit = random.Next(10,100);
            
            //so they will strt off from the bottom of the screen and then theyll work their way up
            posX = random.Next(-10,800);
            posY = random.Next(60,120);

            speedY = random.Next(1,5);




        }

        public void MoveBubble()
        {
            //this is going to be in charge of the movement like where are they coming from and where will the be moving to
            //in charge of moving the bubble left and right 
            moveLimit -= 1;

            if (moveLimit < 1)
            {
                speedX = -speedX;
                moveLimit = random.Next(50, 200);
            }

        }



    }
}
